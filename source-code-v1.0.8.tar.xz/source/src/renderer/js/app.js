let BACKEND_URL = 'http://127.0.0.1:5173';
let backendToken = '';
let backendReady = false;
let backendStartPromise = null;

function setBackendStatus(message, ok = false) {
  els.backendStatus.textContent = `Backend: ${message}`;
  els.backendStatus.style.color = ok ? 'var(--success)' : 'var(--danger)';
}

async function ensureBackendStarted() {
  if (backendReady) return true;
  if (backendStartPromise) return backendStartPromise;

  backendStartPromise = (async () => {
    els.startBackend.disabled = true;
    setBackendStatus('wird gestartet …');
    log('Backend wird gestartet …');
    try {
      const result = await window.electronAPI.startBackend();
      if (!result || !Number.isInteger(Number(result.port)) || !result.token) {
        throw new Error('Backend lieferte keine gültige Port-/Sitzungsinformation.');
      }
      BACKEND_URL = `http://127.0.0.1:${Number(result.port)}`;
      backendToken = result.token;
      backendReady = true;
      setBackendStatus(`läuft (Port ${result.port})`, true);
      els.startBackend.textContent = 'Backend läuft';
      log(`Backend bereit auf Port ${result.port}`);
      return true;
    } catch (error) {
      backendReady = false;
      backendToken = '';
      setBackendStatus('Start fehlgeschlagen');
      els.startBackend.textContent = 'Backend erneut starten';
      log(`Backend-Start fehlgeschlagen: ${error.message}`, 'error');
      throw error;
    } finally {
      els.startBackend.disabled = false;
      backendStartPromise = null;
    }
  })();
  return backendStartPromise;
}

async function backendFetch(url, options = {}) {
  const headers = new Headers(options.headers || {});
  if (backendToken) headers.set('Authorization', `Bearer ${backendToken}`);
  try {
    return await fetch(url, { ...options, headers });
  } catch (firstError) {
    // Recover once when the local backend has exited unexpectedly.
    if (!backendReady) throw firstError;
    backendReady = false;
    await ensureBackendStarted();
    const retryHeaders = new Headers(options.headers || {});
    if (backendToken) retryHeaders.set('Authorization', `Bearer ${backendToken}`);
    const requestUrl = new URL(url);
    return fetch(`${BACKEND_URL}${requestUrl.pathname}${requestUrl.search}`, { ...options, headers: retryHeaders });
  }
}

let state = {
  apiKey: '',
  model: 'nvidia/nemotron-3.5-super-vl:free',
  rootPassword: '',
  mode: 'confirm',
  favorites: [],
};

let streaming = false;
let pendingConfirm = null;
let screenshotBase64 = null;

// DOM
const els = {
  apiKey: document.getElementById('api-key'),
  toggleApiKey: document.getElementById('toggle-api-key'),
  testApiKey: document.getElementById('test-api-key'),
  apiKeyStatus: document.getElementById('api-key-status'),
  modelSelect: document.getElementById('model-select'),
  refreshModels: document.getElementById('refresh-models'),
  favoritesList: document.getElementById('favorites-list'),
  rootPassword: document.getElementById('root-password'),
  modeConfirm: document.getElementById('mode-confirm'),
  modeAutonomous: document.getElementById('mode-autonomous'),
  saveSettings: document.getElementById('save-settings'),
  startBackend: document.getElementById('start-backend'),
  settingsStatus: document.getElementById('settings-status'),
  backendStatus: document.getElementById('backend-status'),
  chatMessages: document.getElementById('chat-messages'),
  chatInput: document.getElementById('chat-input'),
  sendBtn: document.getElementById('send-btn'),
  screenshotBtn: document.getElementById('screenshot-btn'),
  screenshotImg: document.getElementById('screenshot-img'),
  screenshotEmpty: document.querySelector('.empty-hint'),
  screenshotEmptySubhint: document.querySelector('.empty-subhint'),
  screenshotPlaceholder: document.querySelector('.screen-placeholder-art'),
  refreshScreenshot: document.getElementById('refresh-screenshot'),
  logMessages: document.getElementById('log-messages'),
  confirmDialog: document.getElementById('confirm-dialog'),
  dialogMessage: document.getElementById('dialog-message'),
  dialogCommand: document.getElementById('dialog-command'),
  dialogCancel: document.getElementById('dialog-cancel'),
  dialogAllow: document.getElementById('dialog-allow'),
};

function log(msg, type = 'info') {
  const div = document.createElement('div');
  div.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  if (type === 'error') div.style.color = 'var(--danger)';
  els.logMessages.appendChild(div);
  els.logMessages.scrollTop = els.logMessages.scrollHeight;
}

function addMessage(text, sender) {
  const div = document.createElement('div');
  div.className = `message ${sender}`;
  div.textContent = text;
  els.chatMessages.appendChild(div);
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
  return div;
}

function addStreamingMessage() {
  const div = document.createElement('div');
  div.className = 'message ai';
  const cursor = document.createElement('span');
  cursor.className = 'streaming-cursor';
  div.appendChild(document.createTextNode(''));
  div.appendChild(cursor);
  els.chatMessages.appendChild(div);
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
  return { div, text: '', cursor };
}

// Lightweight particle constellation shown while the model is preparing a reply.
// The animation is canvas-based, capped at 30 FPS, and automatically stops when
// the first response token arrives (or when the request ends).
let thinkingAnimation = null;

function hideThinkingAnimation() {
  if (!thinkingAnimation) return;
  if (thinkingAnimation.frame) cancelAnimationFrame(thinkingAnimation.frame);
  if (thinkingAnimation.resizeObserver) thinkingAnimation.resizeObserver.disconnect();
  if (thinkingAnimation.element?.isConnected) thinkingAnimation.element.remove();
  thinkingAnimation = null;
}

function showThinkingAnimation() {
  hideThinkingAnimation();

  const element = document.createElement('div');
  element.className = 'thinking-state';
  element.setAttribute('role', 'status');
  element.setAttribute('aria-label', 'Die KI denkt nach');

  const canvas = document.createElement('canvas');
  canvas.className = 'thinking-canvas';
  canvas.setAttribute('aria-hidden', 'true');

  const copy = document.createElement('div');
  copy.className = 'thinking-copy';
  const title = document.createElement('div');
  title.className = 'thinking-title';
  title.textContent = 'KI denkt nach';
  const subtitle = document.createElement('div');
  subtitle.className = 'thinking-subtitle';
  subtitle.textContent = 'Gedanken verbinden sich …';
  const pulse = document.createElement('span');
  pulse.className = 'thinking-pulse';
  title.prepend(pulse);
  copy.append(title, subtitle);
  element.append(canvas, copy);
  els.chatMessages.appendChild(element);
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;

  const context = canvas.getContext('2d', { alpha: true });
  if (!context) {
    thinkingAnimation = { element, frame: 0, resizeObserver: null };
    return;
  }

  const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const particles = [];
  const particleCount = 200;
  let width = 1;
  let height = 1;
  let lastFrame = 0;
  let frame = 0;

  function resize() {
    const rect = element.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    width = Math.max(1, rect.width);
    height = Math.max(1, rect.height);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!particles.length) {
      for (let i = 0; i < particleCount; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 0.12 + Math.random() * 0.34;
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          phase: Math.random() * Math.PI * 2,
          size: 0.65 + Math.random() * 1.25,
          tone: Math.random(),
        });
      }
    } else {
      particles.forEach(p => {
        p.x = Math.min(p.x, width);
        p.y = Math.min(p.y, height);
      });
    }
  }

  function draw(timestamp = 0) {
    if (!element.isConnected) {
      hideThinkingAnimation();
      return;
    }
    if (!reducedMotion && timestamp - lastFrame < 33) {
      frame = requestAnimationFrame(draw);
      return;
    }
    lastFrame = timestamp;
    context.clearRect(0, 0, width, height);

    const neighbours = Array.from({ length: particles.length }, () => []);
    const maxDistance = Math.min(92, Math.max(54, width * 0.19));
    const maxDistanceSq = maxDistance * maxDistance;

    // Gentle drift keeps the field fluid without a heavy physics simulation.
    if (!reducedMotion) {
      particles.forEach((p, index) => {
        const t = timestamp * 0.00022 + p.phase;
        p.vx += Math.sin(t + index * 0.07) * 0.0022;
        p.vy += Math.cos(t * 0.9 + index * 0.05) * 0.0022;
        const speed = Math.hypot(p.vx, p.vy) || 1;
        const maxSpeed = 0.62;
        if (speed > maxSpeed) {
          p.vx = p.vx / speed * maxSpeed;
          p.vy = p.vy / speed * maxSpeed;
        }
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < -5) p.x = width + 5;
        if (p.x > width + 5) p.x = -5;
        if (p.y < -5) p.y = height + 5;
        if (p.y > height + 5) p.y = -5;
      });
    }

    // Build short-lived links between nearby particles.
    for (let i = 0; i < particles.length; i++) {
      const a = particles[i];
      for (let j = i + 1; j < particles.length; j++) {
        const b = particles[j];
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const distSq = dx * dx + dy * dy;
        if (distSq < maxDistanceSq) {
          const strength = 1 - Math.sqrt(distSq) / maxDistance;
          neighbours[i].push({ index: j, strength });
          neighbours[j].push({ index: i, strength });
        }
      }
    }

    // Draw restrained triangles where three neighbours briefly meet.
    for (let i = 0; i < neighbours.length; i++) {
      const list = neighbours[i].sort((a, b) => b.strength - a.strength).slice(0, 4);
      for (let a = 0; a < list.length; a++) {
        for (let b = a + 1; b < list.length; b++) {
          const j = list[a].index;
          const k = list[b].index;
          if (j <= i || k <= j) continue;
          if (neighbours[j].some(item => item.index === k)) {
            const p1 = particles[i], p2 = particles[j], p3 = particles[k];
            context.beginPath();
            context.moveTo(p1.x, p1.y);
            context.lineTo(p2.x, p2.y);
            context.lineTo(p3.x, p3.y);
            context.closePath();
            context.fillStyle = 'rgba(80, 218, 207, 0.025)';
            context.fill();
          }
        }
      }
    }

    // Fine connecting lines fade with distance; not every point stays connected.
    context.lineWidth = 0.65;
    for (let i = 0; i < neighbours.length; i++) {
      for (const link of neighbours[i]) {
        if (link.index <= i) continue;
        const p = particles[i], q = particles[link.index];
        context.strokeStyle = `rgba(104, 224, 218, ${0.035 + link.strength * 0.24})`;
        context.beginPath();
        context.moveTo(p.x, p.y);
        context.lineTo(q.x, q.y);
        context.stroke();
      }
    }

    // Tiny softly glowing points.
    for (const p of particles) {
      const glow = 0.44 + (Math.sin(timestamp * 0.0014 + p.phase) + 1) * 0.22;
      context.beginPath();
      context.fillStyle = p.tone > 0.78
        ? `rgba(151, 190, 255, ${glow})`
        : `rgba(112, 235, 222, ${glow})`;
      context.shadowColor = p.tone > 0.78 ? 'rgba(151,190,255,.55)' : 'rgba(112,235,222,.55)';
      context.shadowBlur = 5;
      context.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      context.fill();
    }
    context.shadowBlur = 0;

    if (!reducedMotion) frame = requestAnimationFrame(draw);
  }

  resize();
  const resizeObserver = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
  if (resizeObserver) resizeObserver.observe(element);
  thinkingAnimation = { element, frame: 0, resizeObserver };
  draw(0);
  thinkingAnimation.frame = frame;
}

async function loadSettings() {
  try {
    const s = await window.electronAPI.loadSettings();
    if (s.apiKey) {
      els.apiKey.value = s.apiKey;
      state.apiKey = s.apiKey;
    }
    if (s.model) {
      state.model = s.model;
    }
    if (s.mode) {
      state.mode = 'confirm';
      updateModeButtons();
    }
    if (Array.isArray(s.favorites)) {
      state.favorites = s.favorites;
      renderFavorites();
    }
    log('Einstellungen geladen');
  } catch (e) {
    log(`Fehler beim Laden: ${e.message}`, 'error');
  }
}

async function saveSettings() {
  const settings = {
    apiKey: els.apiKey.value.trim(),
    model: state.model,
    rootPassword: '', // niemals speichern
    mode: state.mode,
    favorites: state.favorites,
  };
  try {
    await window.electronAPI.saveSettings(settings);
    state.apiKey = settings.apiKey;
    els.settingsStatus.textContent = 'Gespeichert (chmod 600)';
    els.settingsStatus.className = 'status ok';
    setTimeout(() => { els.settingsStatus.textContent = ''; }, 3000);
    log('Einstellungen gespeichert');
  } catch (e) {
    els.settingsStatus.textContent = `Fehler: ${e.message}`;
    els.settingsStatus.className = 'status err';
    log(`Speicherfehler: ${e.message}`, 'error');
  }
}

async function testApiKey() {
  const key = els.apiKey.value.trim() || state.apiKey;
  if (!key) {
    els.apiKeyStatus.textContent = 'API-Key fehlt';
    els.apiKeyStatus.className = 'key-check-status error';
    return false;
  }
  els.testApiKey.disabled = true;
  els.apiKeyStatus.textContent = 'Prüfe …';
  els.apiKeyStatus.className = 'key-check-status';
  try {
    await ensureBackendStarted();
    const response = await backendFetch(`${BACKEND_URL}/api/key-check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-API-Key': key },
      body: JSON.stringify({}),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ok) throw new Error(result.error || `HTTP ${response.status}`);
    els.apiKeyStatus.textContent = 'Schlüssel gültig';
    els.apiKeyStatus.className = 'key-check-status success';
    log('OpenRouter API-Key direkt aus der App erfolgreich geprüft.');
    return true;
  } catch (error) {
    els.apiKeyStatus.textContent = 'Prüfung fehlgeschlagen';
    els.apiKeyStatus.className = 'key-check-status error';
    log(`OpenRouter-Key-Prüfung: ${error.message}`, 'error');
    return false;
  } finally {
    els.testApiKey.disabled = false;
  }
}

async function fetchModels() {
  const key = els.apiKey.value.trim() || state.apiKey;
  if (!key) {
    log('OpenRouter API-Key erforderlich. Bitte links eintragen und Einstellungen speichern.', 'error');
    return;
  }
  try {
    await ensureBackendStarted();
    const res = await backendFetch(`${BACKEND_URL}/api/models`, {
      headers: { 'X-API-Key': key }
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      log(`Modell-Fehler: ${data.error || `HTTP ${res.status}`}`, 'error');
      return;
    }
    renderModels(data.models);
    log(`${data.models.length} Modelle geladen`);
  } catch (e) {
    log(`Modell-Fehler: ${e.message}`, 'error');
  }
}

function renderModels(models) {
  els.modelSelect.innerHTML = '';
  if (!Array.isArray(models) || models.length === 0) return;

  // If a saved model is no longer offered by OpenRouter, select a real model
  // instead of silently sending chat requests with a stale model identifier.
  if (!models.some(model => model.id === state.model)) {
    const preferred = models.find(model => model.id.toLowerCase().includes('nemotron'));
    state.model = (preferred || models[0]).id;
    log('Gespeichertes Modell ist nicht mehr verfügbar; ein verfügbares Modell wurde ausgewählt.', 'error');
  }

  models.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.id;
    opt.textContent = m.name;
    if (m.id === state.model) opt.selected = true;
    if (state.favorites.includes(m.id)) opt.textContent = '★ ' + opt.textContent;
    els.modelSelect.appendChild(opt);
  });
  els.modelSelect.value = state.model;
}

function renderFavorites() {
  els.favoritesList.innerHTML = '';
  state.favorites.forEach(fid => {
    const chip = document.createElement('div');
    chip.className = 'favorite-chip';
    chip.textContent = fid;
    chip.addEventListener('click', () => {
      state.model = fid;
      els.modelSelect.value = fid;
      log(`Favorit gewählt: ${fid}`);
    });
    els.favoritesList.appendChild(chip);
  });
}

function updateModeButtons() {
  els.modeConfirm.classList.toggle('active', state.mode === 'confirm');
  els.modeAutonomous.classList.toggle('active', state.mode === 'autonomous');
}

async function takeScreenshot({ quiet = false } = {}) {
  try {
    await ensureBackendStarted();
    const res = await backendFetch(`${BACKEND_URL}/api/screenshot`, { method: 'POST' });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.error) throw new Error(data.error || `HTTP ${res.status}`);
    if (typeof data.image !== 'string' || data.image.length < 100) {
      throw new Error('Der Screenshot enthält keine gültigen Bilddaten.');
    }
    screenshotBase64 = data.image;
    els.screenshotImg.src = `data:image/png;base64,${data.image}`;
    els.screenshotImg.style.display = 'block';
    els.screenshotEmpty.style.display = 'none';
    if (els.screenshotEmptySubhint) els.screenshotEmptySubhint.style.display = 'none';
    if (els.screenshotPlaceholder) els.screenshotPlaceholder.style.display = 'none';
    const dimensions = data.width && data.height ? `, ${data.width}×${data.height}` : '';
    log(`Screenshot erstellt (${data.capture_method || 'Desktop-Aufnahme'}${dimensions})`);
    return true;
  } catch (e) {
    screenshotBase64 = null;
    els.screenshotImg.removeAttribute('src');
    els.screenshotImg.style.display = 'none';
    els.screenshotEmpty.style.display = '';
    if (els.screenshotEmptySubhint) els.screenshotEmptySubhint.style.display = '';
    if (els.screenshotPlaceholder) els.screenshotPlaceholder.style.display = '';
    if (!quiet) log(`Screenshot-Fehler: ${e.message}`, 'error');
    return false;
  }
}

function isScreenQuestion(message) {
  return /(bildschirm|bildschirmfoto|bildschirmaufnahme|desktop|\bscreen\b|screenshot|monitor|fenster|was siehst du|siehst du (meinen|den)|kannst du .*sehen)/i.test(message);
}

function appendLogEntry(entry) {
  const div = document.createElement('div');
  const parts = [];
  if (entry.command) parts.push(`$ ${entry.command}`);
  if (entry.stdout) parts.push(entry.stdout);
  if (entry.stderr) parts.push(`STDERR: ${entry.stderr}`);
  if (entry.error) parts.push(`FEHLER: ${entry.error}`);
  if (entry.warning) parts.push(`⚠ ${entry.warning}`);
  div.textContent = parts.join('\n');
  div.style.marginBottom = '8px';
  els.logMessages.appendChild(div);
  els.logMessages.scrollTop = els.logMessages.scrollHeight;
}

async function executeCommand(cmd, useSudo = false) {
  try {
    await ensureBackendStarted();
    const res = await backendFetch(`${BACKEND_URL}/api/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        command: cmd,
        sudo: useSudo,
        root_password: state.rootPassword || '',
        mode: state.mode,
      }),
    });
    const data = await res.json();
    appendLogEntry(data);
    return data;
  } catch (e) {
    log(`Ausführungsfehler: ${e.message}`, 'error');
    return { error: e.message };
  }
}

async function sendMessage() {
  const text = els.chatInput.value.trim();
  if (!text || streaming) return;

  els.chatInput.value = '';
  addMessage(text, 'user');
  log('Nachricht gesendet');

  const streamDiv = addStreamingMessage();
  streamDiv.div.hidden = true;
  streaming = true;
  els.sendBtn.disabled = true;
  showThinkingAnimation();

  try {
    const apiKey = els.apiKey.value.trim() || state.apiKey;
    if (!apiKey) throw new Error('OpenRouter API-Key fehlt. Bitte links eintragen und Einstellungen speichern.');
    await ensureBackendStarted();
    if (isScreenQuestion(text)) {
      const captured = await takeScreenshot();
      if (!captured || !screenshotBase64) {
        throw new Error('Ich kann deinen Bildschirm noch nicht sehen: Die Desktop-Aufnahme ist fehlgeschlagen. Prüfe das Screenshot-Protokoll.');
      }
    }
    const res = await backendFetch(`${BACKEND_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': apiKey
      },
      body: JSON.stringify({
        message: text,
        model: state.model,
        image: screenshotBase64,
        stream: false,
      }),
    });

    const result = await res.json().catch(() => ({}));
    if (!res.ok || result.error) {
      throw new Error(result.error || `HTTP ${res.status}`);
    }

    const fullText = String(result.response || '').trim();
    if (!fullText) throw new Error('OpenRouter hat eine leere Antwort zurückgegeben.');
    hideThinkingAnimation();
    streamDiv.div.hidden = false;
    streamDiv.div.textContent = fullText;
    log('KI-Antwort erhalten');

    // Parse commands from KI response (simple detection of shell-like blocks)
    const commands = extractCommands(fullText);
    if (commands.length > 0) {
      if (state.mode === 'confirm') {
        showConfirmDialog(commands, fullText);
      } else {
        showConfirmDialog(commands, fullText);
      }
    }

  } catch (e) {
    hideThinkingAnimation();
    streamDiv.div.hidden = false;
    log(`Chat-Fehler: ${e.message}`, 'error');
    streamDiv.div.textContent = `Fehler: ${e.message}`;
    const cursor = streamDiv.div.querySelector('.streaming-cursor');
    if (cursor) cursor.remove();
  } finally {
    hideThinkingAnimation();
    streaming = false;
    els.sendBtn.disabled = false;
  }
}

function extractCommands(text) {
  const commands = [];
  const codeBlockRegex = /```(?:sh|bash|shell)?\n([\s\S]*?)```/g;
  let match;
  while ((match = codeBlockRegex.exec(text)) !== null) {
    const cmd = match[1].trim();
    if (cmd) commands.push(cmd);
  }
  return commands;
}

function showConfirmDialog(commands, context) {
  pendingConfirm = { commands, context };
  if (commands.length === 1) {
    els.dialogMessage.textContent = 'Die KI schlägt folgende Aktion vor:';
  } else {
    els.dialogMessage.textContent = `Die KI schlägt ${commands.length} Aktionen vor (werden nacheinander ausgeführt):`;
  }
  els.dialogCommand.textContent = commands.join('\n\n---\n\n');
  els.confirmDialog.showModal();
}

function hideConfirmDialog() {
  pendingConfirm = null;
  els.confirmDialog.close();
}

// Event listeners
els.toggleApiKey.addEventListener('click', () => {
  const type = els.apiKey.type === 'password' ? 'text' : 'password';
  els.apiKey.type = type;
  els.toggleApiKey.textContent = type === 'password' ? '👁' : '🙈';
});

els.refreshModels.addEventListener('click', fetchModels);
els.testApiKey.addEventListener('click', testApiKey);

els.modelSelect.addEventListener('change', (e) => {
  state.model = e.target.value.replace(/^★\s*/, '');
});

els.saveSettings.addEventListener('click', saveSettings);

els.startBackend.addEventListener('click', async () => {
  try {
    await ensureBackendStarted();
    await fetchModels();
  } catch (error) {
    // The detailed cause is already written by ensureBackendStarted().
  }
});

els.modeConfirm.addEventListener('click', () => {
  state.mode = 'confirm';
  updateModeButtons();
});

els.modeAutonomous.addEventListener('click', () => {
  state.mode = 'confirm';
  updateModeButtons();
  log('Der autonome Modus ist aus Sicherheitsgründen deaktiviert. Aktionen benötigen eine Bestätigung.', 'error');
});

els.rootPassword.addEventListener('input', (e) => {
  state.rootPassword = e.target.value;
});

els.sendBtn.addEventListener('click', sendMessage);

els.chatInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

els.screenshotBtn.addEventListener('click', takeScreenshot);

els.refreshScreenshot.addEventListener('click', takeScreenshot);

els.dialogCancel.addEventListener('click', () => {
  hideConfirmDialog();
  log('Befehl abgelehnt');
});

els.dialogAllow.addEventListener('click', async () => {
  if (!pendingConfirm) return;
  const { commands } = pendingConfirm;
  hideConfirmDialog();
  for (const cmd of commands) {
    // Detect if command needs sudo (starts with sudo or contains sudo)
    const needsSudo = cmd.trim().startsWith('sudo ') || cmd.includes(' sudo ');
    await executeCommand(cmd, needsSudo);
  }
});

// Init
window.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  updateModeButtons();
  renderFavorites();

  // Start the local Python service automatically so the first chat message
  // does not fail with 'Failed to fetch' merely because the user missed the
  // separate backend button.
  try {
    await ensureBackendStarted();
    if (state.apiKey || els.apiKey.value.trim()) await fetchModels();
    else log('Backend läuft. OpenRouter API-Key eintragen, um Modelle zu laden.');
  } catch (error) {
    log(`Automatischer Backend-Start fehlgeschlagen: ${error.message}`, 'error');
  }
});
