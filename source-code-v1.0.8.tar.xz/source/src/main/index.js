const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const http = require('http');
const { spawn } = require('child_process');
const net = require('net');

let mainWindow = null;
let backendProcess = null;
let backendTmpDir = null;
let backendPort = null;
let backendToken = null;
let backendOutput = '';
let backendSpawnError = null;
const SETTINGS_PATH = path.join(os.homedir(), '.config', 'pi-air-pc-control', 'settings.json');

function findFreePort(start = 5173, end = 5273) {
  return new Promise((resolve, reject) => {
    function tryPort(port) {
      if (port > end) return reject(new Error('Kein freier lokaler Port zwischen 5173 und 5273 gefunden.'));
      const server = net.createServer();
      server.once('error', () => tryPort(port + 1));
      server.once('listening', () => server.close(() => resolve(port)));
      server.listen(port, '127.0.0.1');
    }
    tryPort(start);
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(app.getAppPath(), 'assets', 'icon.png'),
  });

  mainWindow.loadFile(path.join(app.getAppPath(), 'src', 'renderer', 'index.html'));
  mainWindow.on('closed', () => {
    mainWindow = null;
    stopBackend();
  });
}

function ensureSettingsDir() {
  const settingsDir = path.dirname(SETTINGS_PATH);
  fs.mkdirSync(settingsDir, { recursive: true, mode: 0o700 });
  fs.chmodSync(settingsDir, 0o700);
}

function loadSettings() {
  try {
    if (fs.existsSync(SETTINGS_PATH)) {
      const data = fs.readFileSync(SETTINGS_PATH, 'utf8');
      const parsed = JSON.parse(data);
      return parsed && typeof parsed === 'object' ? parsed : {};
    }
  } catch (error) {
    console.error(`[settings] Einstellungen konnten nicht gelesen werden: ${error.message}`);
  }
  return {};
}

function saveSettings(settings) {
  if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
    throw new Error('Ungültige Einstellungen.');
  }
  ensureSettingsDir();
  const safeSettings = {
    apiKey: String(settings.apiKey || '').trim(),
    model: String(settings.model || 'nvidia/nemotron-3.5-super-vl:free'),
    mode: 'confirm',
    favorites: Array.isArray(settings.favorites) ? settings.favorites.filter(x => typeof x === 'string').slice(0, 100) : [],
  };
  const tempPath = `${SETTINGS_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(safeSettings, null, 2), { mode: 0o600 });
  fs.renameSync(tempPath, SETTINGS_PATH);
  fs.chmodSync(SETTINGS_PATH, 0o600);
}

function waitForBackendHealth(port, child, timeout = 25000) {
  const startedAt = Date.now();
  return new Promise((resolve, reject) => {
    let finished = false;
    let retryTimer = null;

    const finish = (error) => {
      if (finished) return;
      finished = true;
      if (retryTimer) clearTimeout(retryTimer);
      if (error) reject(error);
      else resolve(port);
    };

    const check = () => {
      if (finished) return;
      if (backendSpawnError) return finish(new Error(`Python konnte nicht gestartet werden: ${backendSpawnError.message}`));
      if (child.exitCode !== null || child.signalCode !== null) {
        const details = backendOutput.trim().slice(-1600);
        return finish(new Error(`Backend-Prozess wurde vor dem Start beendet (Code ${child.exitCode}, Signal ${child.signalCode || 'keins'}).${details ? `\n${details}` : ''}`));
      }
      if (Date.now() - startedAt > timeout) {
        const details = backendOutput.trim().slice(-1600);
        return finish(new Error(`Backend-Health-Check nach ${Math.round(timeout / 1000)} Sekunden fehlgeschlagen.${details ? `\n${details}` : '\nPrüfe die Python-Abhängigkeiten und das Backend-Log.'}`));
      }

      const req = http.get({ hostname: '127.0.0.1', port, path: '/api/health', timeout: 1200 }, (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(body);
            if (res.statusCode === 200 && parsed.ok === true) return finish();
          } catch (_) {
            // Flask may still be starting; retry below.
          }
          retryTimer = setTimeout(check, 250);
        });
      });
      req.on('timeout', () => req.destroy(new Error('Health-Check Zeitüberschreitung')));
      req.on('error', () => {
        retryTimer = setTimeout(check, 250);
      });
    };

    child.once('error', (error) => {
      backendSpawnError = error;
      finish(new Error(`Python konnte nicht gestartet werden: ${error.message}`));
    });
    check();
  });
}

async function startBackend() {
  if (backendProcess && backendPort && backendToken && backendProcess.exitCode === null && !backendProcess.killed) {
    return { port: backendPort, token: backendToken };
  }
  // Discard stale state if the child already exited before its exit event was handled.
  if (backendProcess && (backendProcess.exitCode !== null || backendProcess.killed)) {
    backendProcess = null;
    backendPort = null;
    backendToken = null;
  }

  backendPort = await findFreePort();
  backendToken = crypto.randomBytes(32).toString('hex');
  backendOutput = '';
  backendSpawnError = null;

  const python = process.env.AIR_PC_PYTHON || process.env.PYTHON || 'python3';
  console.log(`[backend] Python-Interpreter: ${python}`);
  const appPath = app.getAppPath();
  const backendSourcePath = path.join(appPath, 'backend', 'server.py');
  if (!fs.existsSync(backendSourcePath)) {
    backendPort = null;
    backendToken = null;
    throw new Error(`Backend-Datei fehlt: ${backendSourcePath}`);
  }

  // Python kann eine Datei im Electron-ASAR nicht direkt als Skript starten.
  // Daher wird sie aus dem richtigen App-Root in ein temporäres Verzeichnis kopiert.
  backendTmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'pi-air-pc-backend-'));
  const scriptPath = path.join(backendTmpDir, 'server.py');
  fs.copyFileSync(backendSourcePath, scriptPath);
  fs.chmodSync(scriptPath, 0o700);

  const child = spawn(python, [scriptPath, '--port', String(backendPort)], {
    cwd: backendTmpDir,
    env: { ...process.env, AIR_PC_SESSION_TOKEN: backendToken, PYTHONUNBUFFERED: '1' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  backendProcess = child;
  child.stdout.on('data', (data) => {
    const value = data.toString();
    backendOutput = (backendOutput + value).slice(-8000);
    console.log(`[backend] ${value.trimEnd()}`);
  });
  child.stderr.on('data', (data) => {
    const value = data.toString();
    backendOutput = (backendOutput + value).slice(-8000);
    console.error(`[backend] ${value.trimEnd()}`);
  });
  child.on('exit', (code, signal) => {
    console.log(`[backend] beendet (Code ${code}, Signal ${signal})`);
    backendProcess = null;
    backendPort = null;
    backendToken = null;
  });

  try {
    await waitForBackendHealth(backendPort, child);
    console.log(`[backend] bereit auf Port ${backendPort}`);
    return { port: backendPort, token: backendToken };
  } catch (error) {
    const message = error.message;
    stopBackend();
    throw new Error(message);
  }
}

function stopBackend() {
  if (backendProcess) {
    const child = backendProcess;
    backendProcess = null;
    try {
      child.kill('SIGTERM');
      const forceKillTimer = setTimeout(() => {
        if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
      }, 3000);
      forceKillTimer.unref();
      child.once('exit', () => clearTimeout(forceKillTimer));
    } catch (error) {
      console.error(`[backend] Stop-Fehler: ${error.message}`);
    }
  }
  if (backendTmpDir) {
    try { fs.rmSync(backendTmpDir, { recursive: true, force: true }); } catch (_) {}
    backendTmpDir = null;
  }
  backendPort = null;
  backendToken = null;
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', stopBackend);
app.on('window-all-closed', () => {
  stopBackend();
  if (process.platform !== 'darwin') app.quit();
});
process.on('SIGTERM', () => { stopBackend(); app.quit(); });
process.on('SIGINT', () => { stopBackend(); app.quit(); });

ipcMain.handle('start-backend', async () => startBackend());
ipcMain.handle('stop-backend', () => { stopBackend(); return { ok: true }; });
ipcMain.handle('load-settings', () => loadSettings());
ipcMain.handle('save-settings', (event, settings) => { saveSettings(settings); return { ok: true }; });
