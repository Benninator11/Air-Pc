#!/usr/bin/env python3
"""Local Flask backend for Pi Air PC Control."""

import argparse
import base64
import hmac
import io
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import requests
from flask import Flask, request, jsonify, Response
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

STATE = {
    "api_key": None,
    "model": "nvidia/nemotron-3.5-super-vl:free",
    "root_password": None,
    "mode": "confirm",
    "favorites": [],
}

DANGEROUS_COMMAND_PATTERNS = [
    re.compile(r"(?:^|[;&|]\s*)rm\s+[^;&|]*-(?:rf|fr)[^;&|]*\s+/+(?:\s|$)"),
    re.compile(r"(?:^|[;&|]\s*)mkfs(?:\.[a-z0-9_-]+)?\b"),
    re.compile(r"(?:^|[;&|]\s*)dd\b[^;&|]*\bof=/dev/"),
    re.compile(r"(?:^|[;&|]\s*)(?:shutdown|reboot|poweroff|halt|passwd|fdisk|gdisk)\b"),
    re.compile(r"(?:^|[;&|]\s*)(?:chmod|chown)\s+-R\b"),
    re.compile(r":\(\)\s*\{\s*:\|:&\s*\};:"),
]


def is_blacklisted(cmd: str) -> bool:
    # Ignore a leading sudo wrapper so that `sudo reboot` is checked too.
    normalized = re.sub(r"\bsudo\s+", "", cmd.strip().lower())
    return any(pattern.search(normalized) for pattern in DANGEROUS_COMMAND_PATTERNS)


def normalize_openrouter_api_key(value) -> str:
    """Normalize common copy/paste formats without logging or exposing the key."""
    key = str(value or '').strip().strip('"\'')
    if key[:7].lower() == 'bearer ':
        key = key[7:].strip()
    return key


def validate_command(cmd: str) -> tuple[bool, str]:
    if not cmd or not isinstance(cmd, str):
        return False, "Command must be a non-empty string"
    if len(cmd) > 4096:
        return False, "Command too long (max 4096 chars)"
    if '\x00' in cmd:
        return False, "Command contains null bytes"
    return True, ""


@app.before_request
def require_local_session_token():
    # The Electron main process creates a fresh secret for every backend run.
    # Health stays open only on loopback so Electron can perform its startup check.
    if request.path == '/api/health' or request.method == 'OPTIONS':
        return None
    expected = os.environ.get('AIR_PC_SESSION_TOKEN', '')
    supplied = request.headers.get('Authorization', '')
    if not expected or not hmac.compare_digest(supplied, f'Bearer {expected}'):
        return jsonify({"error": "Nicht autorisierte lokale Sitzung."}), 401
    return None


@app.route('/api/models', methods=['GET'])
def get_models():
    api_key = normalize_openrouter_api_key(request.headers.get('X-API-Key') or STATE.get('api_key'))
    if not api_key:
        return jsonify({"error": "No API key set", "models": []}), 400
    try:
        resp = requests.get(
            'https://openrouter.ai/api/v1/models',
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=20,
        )
        if resp.status_code != 200:
            return jsonify({"error": f"OpenRouter error: {resp.status_code}", "models": []}), resp.status_code
        payload = resp.json()
        models = [
            {"id": item.get('id', ''), "name": item.get('name') or item.get('id', '')}
            for item in payload.get('data', []) if item.get('id')
        ]
        models.sort(key=lambda item: item['name'].lower())
        return jsonify({"models": models, "favorites": STATE.get('favorites', [])})
    except requests.RequestException as exc:
        return jsonify({"error": f"OpenRouter-Verbindung fehlgeschlagen: {exc}", "models": []}), 502
    except (ValueError, TypeError) as exc:
        return jsonify({"error": f"Ungültige Antwort von OpenRouter: {exc}", "models": []}), 502


@app.route('/api/key-check', methods=['POST'])
def check_openrouter_key():
    data = request.get_json(silent=True) or {}
    api_key = normalize_openrouter_api_key(data.get('api_key') or request.headers.get('X-API-Key'))
    if not api_key:
        return jsonify({"ok": False, "error": "OpenRouter API-Key fehlt."}), 400
    try:
        response = requests.get(
            'https://openrouter.ai/api/v1/key',
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=15,
        )
        if response.status_code != 200:
            # Never include the API key in diagnostics or logs.
            detail = response.text[:500]
            return jsonify({"ok": False, "error": f"OpenRouter HTTP {response.status_code}: {detail}"}), response.status_code
        return jsonify({"ok": True, "message": "OpenRouter API-Key ist gültig."})
    except requests.RequestException as exc:
        return jsonify({"ok": False, "error": f"OpenRouter-Verbindung fehlgeschlagen: {exc}"}), 502


@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get('message', ''))
    model = data.get('model') or STATE.get('model')
    api_key = normalize_openrouter_api_key(data.get('api_key') or request.headers.get('X-API-Key') or STATE.get('api_key'))
    image_b64 = data.get('image')
    stream = bool(data.get('stream', True))
    if not api_key:
        return jsonify({"error": "No API key provided"}), 400
    if not message.strip():
        return jsonify({"error": "Leere Nachricht."}), 400

    if image_b64:
        # Multimodal requests require the structured content-array format.
        content = [
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
            {"type": "text", "text": message},
        ]
    else:
        # Keep ordinary text requests identical to OpenRouter's documented
        # and locally verified simple chat-completions shape.
        content = message
    messages = [{"role": "user", "content": content}]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost",
        "X-Title": "Pi Air PC Control",
    }
    payload = {"model": model, "messages": messages, "stream": stream}

    if stream:
        def generate():
            try:
                with requests.post(
                    'https://openrouter.ai/api/v1/chat/completions',
                    headers=headers, json=payload, stream=True, timeout=(15, 120),
                ) as response:
                    if response.status_code != 200:
                        detail = response.text[:1500]
                        yield f"data: {{\"error\": {json_string(f'OpenRouter HTTP {response.status_code}: {detail}')} }}\n\n"
                        return
                    for raw_line in response.iter_lines():
                        if not raw_line:
                            continue
                        line = raw_line.decode('utf-8', errors='replace') if isinstance(raw_line, bytes) else raw_line
                        if line.startswith('data:'):
                            data_line = line[5:].strip()
                            if data_line == '[DONE]':
                                yield 'data: [DONE]\n\n'
                            else:
                                yield f"data: {data_line}\n\n"
            except requests.RequestException as exc:
                yield f"data: {{\"error\": {json_string(str(exc))} }}\n\n"
        return Response(generate(), mimetype='text/event-stream', headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    try:
        response = requests.post(
            'https://openrouter.ai/api/v1/chat/completions',
            headers=headers, json={**payload, "stream": False}, timeout=(15, 120),
        )
        if response.status_code != 200:
            return jsonify({"error": f"OpenRouter HTTP {response.status_code}: {response.text[:1500]}"}), response.status_code
        result = response.json()
        answer = result.get('choices', [{}])[0].get('message', {}).get('content', '')
        return jsonify({"response": answer})
    except requests.RequestException as exc:
        return jsonify({"error": str(exc)}), 502


def json_string(value: str) -> str:
    import json
    return json.dumps(value, ensure_ascii=False)


@app.route('/api/execute', methods=['POST'])
def execute():
    data = request.get_json(silent=True) or {}
    cmd = data.get('command', '')
    use_sudo = bool(data.get('sudo', False))
    root_pw = data.get('root_password') or STATE.get('root_password')

    valid, error = validate_command(cmd)
    if not valid:
        return jsonify({"error": error}), 400
    if is_blacklisted(cmd):
        return jsonify({"error": "Dieser Befehl ist aus Sicherheitsgründen gesperrt.", "blocked": True}), 403

    try:
        if use_sudo:
            if not root_pw:
                return jsonify({"error": "Root password required for sudo commands"}), 400
            # Use a login shell so confirmed multi-part commands keep their semantics.
            shell_command = cmd.strip()
            if shell_command.startswith('sudo '):
                shell_command = shell_command[5:]
            proc = subprocess.run(
                ['sudo', '-S', '-p', '', '--', '/bin/bash', '-lc', shell_command],
                input=f"{root_pw}\n", capture_output=True, text=True, timeout=180,
            )
        else:
            proc = subprocess.run(
                cmd, shell=True, executable='/bin/bash', capture_output=True,
                text=True, timeout=180,
            )
        return jsonify({
            "stdout": proc.stdout, "stderr": proc.stderr,
            "exit_code": proc.returncode, "command": cmd,
            "blocked": False, "warning": None,
        })
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Command timed out", "exit_code": -1}), 504
    except Exception as exc:
        return jsonify({"error": str(exc), "exit_code": -1}), 500


def _validate_screenshot(image_bytes: bytes):
    """Decode and reject a near-uniform black frame before sending it to the model."""
    from PIL import Image, ImageStat
    with Image.open(io.BytesIO(image_bytes)) as source:
        image = source.convert('RGB')
    width, height = image.size
    if width < 160 or height < 120:
        raise RuntimeError(f'Screenshot ist unerwartet klein ({width}x{height}).')
    sample = image.copy()
    sample.thumbnail((96, 96))
    stats = ImageStat.Stat(sample)
    if max(stats.mean) < 4 and max(stats.stddev) < 2:
        raise RuntimeError('Die Aufnahme ist fast vollständig schwarz. Wayland/X11-Aufnahme wird mit einer anderen Methode erneut versucht.')
    if width > 1920:
        new_height = max(1, round(height * (1920 / width)))
        image = image.resize((1920, new_height), Image.Resampling.LANCZOS)
    output = io.BytesIO()
    image.save(output, format='PNG', optimize=True)
    return output.getvalue(), image.size


def _capture_with_program(program, args):
    """Capture to a fresh temporary PNG and return its bytes."""
    with tempfile.TemporaryDirectory(prefix='pi-air-pc-screen-') as tmp_dir:
        output_path = str(Path(tmp_dir) / 'desktop.png')
        result = subprocess.run(
            [program, *args, output_path], capture_output=True, text=True, timeout=18,
            check=False,
        )
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or f'Exit-Code {result.returncode}').strip()
            raise RuntimeError(detail[:400])
        if not os.path.isfile(output_path) or os.path.getsize(output_path) < 128:
            raise RuntimeError('Das Screenshot-Programm hat keine gültige Bilddatei erstellt.')
        with open(output_path, 'rb') as image_file:
            return image_file.read()


def _capture_with_mss():
    import mss
    from PIL import Image
    with mss.MSS() as screen:
        if not screen.monitors:
            raise RuntimeError('Kein Bildschirm gefunden.')
        monitor = screen.monitors[1] if len(screen.monitors) > 1 else screen.monitors[0]
        grabbed = screen.grab(monitor)
        image = Image.frombytes('RGB', grabbed.size, grabbed.rgb)
        output = io.BytesIO()
        image.save(output, format='PNG')
        return output.getvalue()


@app.route('/api/screenshot', methods=['POST'])
def screenshot():
    """Capture the real desktop using the active display server's native tool."""
    wayland = bool(os.environ.get('WAYLAND_DISPLAY')) or os.environ.get('XDG_SESSION_TYPE', '').lower() == 'wayland'
    attempts = []
    methods = []
    if wayland:
        methods.append(('grim', []))
    if os.environ.get('DISPLAY'):
        methods.append(('scrot', ['-q', '85']))
    # MSS is a reasonable X11 fallback, but on Wayland it may return an all-black frame.
    methods.append(('__mss__', []))

    for program, args in methods:
        try:
            raw = _capture_with_mss() if program == '__mss__' else _capture_with_program(program, args)
            normalized, dimensions = _validate_screenshot(raw)
            encoded = base64.b64encode(normalized).decode('ascii')
            return jsonify({
                'image': encoded,
                'width': dimensions[0],
                'height': dimensions[1],
                'capture_method': 'MSS' if program == '__mss__' else program,
            })
        except FileNotFoundError:
            attempts.append(f'{program}: nicht installiert')
        except Exception as exc:
            attempts.append(f'{program}: {exc}')

    session_hint = 'Wayland erkannt; bitte die App in der aktiven Raspberry-Pi-Desktop-Sitzung starten.' if wayland else 'Prüfe, ob die App in einer aktiven grafischen Sitzung läuft.'
    detail = ' | '.join(attempts[-3:]) or 'Keine Screenshot-Methode verfügbar.'
    return jsonify({
        'error': f'Screenshot fehlgeschlagen: {detail}. {session_hint}',
        'black_frame_rejected': True,
    }), 503


@app.route('/api/mouse', methods=['POST'])
def mouse():
    data = request.get_json(silent=True) or {}
    try:
        x, y = int(data.get('x')), int(data.get('y'))
        clicks = max(1, min(int(data.get('clicks', 1)), 3))
        button = data.get('button', 'left')
        if x < 0 or y < 0 or button not in ('left', 'right', 'middle'):
            raise ValueError('Ungültige Mausparameter.')
        import pyautogui
        pyautogui.click(x=x, y=y, button=button, clicks=clicks)
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"error": f"Maussteuerung fehlgeschlagen: {exc}"}), 500


@app.route('/api/keyboard', methods=['POST'])
def keyboard():
    data = request.get_json(silent=True) or {}
    keys = data.get('keys', [])
    text = data.get('text', '')
    if not isinstance(keys, list) or not isinstance(text, str) or len(text) > 2000:
        return jsonify({"error": "Ungültige Tastatureingabe."}), 400
    try:
        import pyautogui
        if keys:
            pyautogui.hotkey(*[str(key) for key in keys[:6]])
        if text:
            pyautogui.write(text)
        return jsonify({"ok": True})
    except Exception as exc:
        return jsonify({"error": f"Tastatursteuerung fehlgeschlagen: {exc}"}), 500


@app.route('/api/sudo-test', methods=['POST'])
def sudo_test():
    data = request.get_json(silent=True) or {}
    password = data.get('root_password', '')
    if not password:
        return jsonify({"ok": False, "error": "No password provided"}), 400
    try:
        result = subprocess.run(
            ['sudo', '-S', '-p', '', 'true'], input=f"{password}\n",
            capture_output=True, text=True, timeout=10,
        )
        return jsonify({"ok": result.returncode == 0})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 500


@app.route('/api/state', methods=['GET', 'POST'])
def state():
    if request.method == 'POST':
        data = request.get_json(silent=True) or {}
        for key in ('api_key', 'model', 'mode', 'favorites'):
            if key in data:
                STATE[key] = data[key]
        return jsonify({key: STATE[key] for key in ('api_key', 'model', 'mode', 'favorites')})
    return jsonify({key: STATE[key] for key in ('api_key', 'model', 'mode', 'favorites')})


@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({"ok": True, "port": STATE.get('_port', 5173)})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=5173)
    args = parser.parse_args()
    STATE['_port'] = args.port
    app.run(host='127.0.0.1', port=args.port, debug=False, use_reloader=False, threaded=True)
